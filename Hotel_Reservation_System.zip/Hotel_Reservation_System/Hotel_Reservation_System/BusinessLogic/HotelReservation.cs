﻿using Hotel_Reservation_System.Constants;
using HotelReservationSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hotel_Reservation_System.Business
{
    public class HotelReservation
    {
        private int roomSize;
        public HotelReservation()
        {
            Console.WriteLine(AppConstants.WELCOME_MESSAGE);
        }

        #region reservation process
        /**
         * Logic to get room size from user through console.
         * Validates the number entered and returns the room size.
         **/
        public int GetRoomSize()
        {
            Console.WriteLine(AppConstants.CAPTURE_ROOM_SIZE_LABEL);
            while (true)
            {
                roomSize = Convert.ToInt32(Console.ReadLine());
                if (roomSize <= AppConstants.MAX_ROOM_SIZE)
                {
                    break;
                }
                Console.WriteLine(AppConstants.DECLINE_MESSAGE);
                Console.WriteLine(AppConstants.INVALID_ROOM_SIZE_MESSAGE);
            }
            return roomSize;
        }
        /**
         * Logic to get process the reservation.
         * Prompts message to input the arrival/departure days in the format 1,2.
         **/
        public void ProcessReservation(int roomSize)
        {
            string bookingDates;
            List<Reservation> reservationDatesList = new List<Reservation>();
            Console.WriteLine(AppConstants.CAPTURE_BOOKING_DAYS_LABEL);

            while ((bookingDates = Console.ReadLine()) != null)
            {
                if (!string.IsNullOrEmpty(bookingDates))
                {
                    int[] datesToReserve = bookingDates.Split(',').Select(int.Parse).ToArray();
                    var isInvalidBookingDate = ValidateBookingDate(datesToReserve);
                    if (!isInvalidBookingDate)
                    {
                        // Assign the booking slots to a class as it is useful in case if we need to process the bookings through external sources. e.g, From JSON / csv files.
                        // Split the user entered dates with the assumption of the first day is a start day and second day is an end day.
                        var arrivalDay = new Reservation { StartDayEndDay = datesToReserve[0], IsCheckIn = true };
                        var departureDay = new Reservation { StartDayEndDay = datesToReserve[1], IsCheckIn = false };
                        // Add the values to an auxiliary list.
                        reservationDatesList.Add(arrivalDay);
                        reservationDatesList.Add(departureDay);
                        // Check if the booking slots available.
                        var isReservationPossible = IsBookingSlotsAvailable(reservationDatesList, roomSize);
                        // If no slots available, delete the current declined dates from auxiliary list.
                        if (!isReservationPossible)
                        {
                            CleanUpTheCurrentSlot(reservationDatesList, arrivalDay, departureDay);
                        }
                        var acceptOrDecline = isReservationPossible ? AppConstants.ACCEPT_MESSAGE : AppConstants.DECLINE_MESSAGE;
                        Console.WriteLine(acceptOrDecline);
                    }
                    else
                    {
                        Console.WriteLine(AppConstants.DECLINE_MESSAGE);
                        Console.WriteLine(AppConstants.INVALID_BOOKING_DAYS_MESSAGE);
                    }
                }
                else
                {
                    break;
                }
            }
        }
        /**
        * Logic to get check if the entered days can be reserved or not.
        **/

        #endregion

        #region validation logic
        private bool IsBookingSlotsAvailable(List<Reservation> reservations, int roomSize)
        {
            var availableRoomCount = roomSize;
            var checkOutDayIndex = 0;
            // Decrement the room count as by default the first reservation is accepted.
            availableRoomCount--;
            // Sort the reservation list to check for the overlapping booking slots.
            reservations = reservations.OrderBy(a => a.StartDayEndDay).ToList();
            var checkInDays = reservations.Where(a => a.IsCheckIn).Select(a => a.StartDayEndDay).ToList();
            var checkOutDays = reservations.Where(a => !a.IsCheckIn).Select(a => a.StartDayEndDay).ToList();
            // Check if the booking overlaps from the 2nd booking request.
            for (var overlappingIndex = 1; overlappingIndex < checkInDays.Count; overlappingIndex++)
            {
                // Check if the running sum for start days and end days overlaps.
                // If no overlap, then de occupy the room for next available booking slot.
                if (checkOutDays.ElementAt(checkOutDayIndex) < checkInDays.ElementAt(overlappingIndex))
                {
                    availableRoomCount++;
                    checkOutDayIndex++;
                }
                // If the reservation is available for a particular day, ocupy the room.
                availableRoomCount--;
                // At any point, if the room is unavailable, decline the reservation.
                if (availableRoomCount < 0) return false;
            }
            return true;
        }
        /**
        * Logic to validate if the entered booking days.
        **/
        private bool ValidateBookingDate(int[] datesToReserve)
        {
            return (datesToReserve[0] > datesToReserve[1] || datesToReserve[0] < AppConstants.MIN_RESERVATION_DAY
                        || datesToReserve[1] < AppConstants.MIN_RESERVATION_DAY || datesToReserve[0] > AppConstants.MAX_RESERVATION_DAY
                        || datesToReserve[1] > AppConstants.MAX_RESERVATION_DAY);
        }
        /**
        * Logic to cleanup the declined reservation days.
        **/
        private void CleanUpTheCurrentSlot(List<Reservation> reservationDatesList, Reservation arrivalDay, Reservation departureDay)
        {
            reservationDatesList.Remove(arrivalDay);
            reservationDatesList.Remove(departureDay);
        }
        #endregion
    }
}
