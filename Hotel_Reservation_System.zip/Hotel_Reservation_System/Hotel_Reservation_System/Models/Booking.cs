﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservationSystem.Models
{
    public class Reservation
    {
        public int StartDayEndDay { get; set; }
        public bool IsCheckIn { get; set; }
    }
}
