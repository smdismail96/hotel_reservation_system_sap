﻿using Hotel_Reservation_System.Business;
using Hotel_Reservation_System.Constants;
using HotelReservationSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HotelReservationSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                /* Process Hotel Reservation. */
                var reservation = new HotelReservation();
                var roomSize = reservation.GetRoomSize();
                reservation.ProcessReservation(roomSize);
            }
            catch (Exception ex)
            {
                Console.WriteLine(AppConstants.ERROR_MESSAGE);
            }
            
        }
    }
}
