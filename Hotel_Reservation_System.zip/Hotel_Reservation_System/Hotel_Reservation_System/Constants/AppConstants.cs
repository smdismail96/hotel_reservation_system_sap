﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hotel_Reservation_System.Constants
{
    public static class AppConstants
    {
        public const int MAX_ROOM_SIZE = 1000;
        public const int MAX_RESERVATION_DAY = 365;
        public const int MIN_RESERVATION_DAY = 0;
        public const string ACCEPT_MESSAGE = "Accept";
        public const string DECLINE_MESSAGE = "Decline";
        public const string WELCOME_MESSAGE = "Welcome to Hotel Reservation System !";
        public const string CAPTURE_ROOM_SIZE_LABEL = "Please enter the number of rooms available in the Hotel.";
        public const string CAPTURE_BOOKING_DAYS_LABEL = "Please enter the start and end days seperated by comma.e.g., " +
                                                            "Enter 1,2 where 1 represents start day and 2 represents end day.";
        public const string INVALID_BOOKING_DAYS_MESSAGE = "Please enter a valid start and end days. The days must be between 0 to 365 only.";
        public const string INVALID_ROOM_SIZE_MESSAGE = "Please enter a room size less than 1000.";
        public const string ERROR_MESSAGE = "Some error occured. Please re launch the application";
    }
}
