using Hotel_Reservation_System.Business;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace HotelReservationSystemUnitTest
{
    [TestClass]
    public class HotelReservationUnitTest
    {
        [TestMethod]
        public void GetRoomSizeTest()
        {
            // Arrange
            var givenRoomSize = "4";
            var givenInput = new StringReader(givenRoomSize);
            Console.SetIn(givenInput);
            var mockOutput = new StringWriter();
            Console.SetOut(mockOutput);
            var hotelReservation = new HotelReservation();   
            
            //Act  
            int actualRoomSize = hotelReservation.GetRoomSize();

            //Assert
            Assert.AreEqual(Convert.ToInt32(givenRoomSize), actualRoomSize);           
        }

        [TestMethod]
        public void ProcessReservationTest()
        {
            // Arrange
            var givenRoomSize = 1;
            var givenSuccessStartEndDays = "1,3";
            var givenSuccessInput = new StringReader(givenSuccessStartEndDays);
            Console.SetIn(givenSuccessInput);
            var mockSuccessOutput = new StringWriter();
            Console.SetOut(mockSuccessOutput);
            var expectedSuccessMessage = "Accept";

            var hotelReservation = new HotelReservation();
            //Act  
            hotelReservation.ProcessReservation(givenRoomSize);
            //Assert
            StringAssert.Contains(mockSuccessOutput.ToString(), expectedSuccessMessage);


            // Arrange
            var givenFailureStartEndDays = "-3,5";
            var givenFailureInput = new StringReader(givenFailureStartEndDays);
            Console.SetIn(givenFailureInput);
            var mockFailureOutput = new StringWriter();
            Console.SetOut(mockFailureOutput);
            var expectedFailureMessage = "Decline";

            //Act  
            hotelReservation.ProcessReservation(givenRoomSize);
            //Assert
            StringAssert.Contains(expectedFailureMessage.ToString(), expectedFailureMessage);
        }

    }
}
